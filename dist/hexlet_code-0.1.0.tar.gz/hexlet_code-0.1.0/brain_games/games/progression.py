import prompt
from random import randint
from math import gcd
#  from brain_games.cli import welcome_user
#  DOD: guess the numbers missing in given progression


def welcome_user():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    return name

#  The function accepts 5 arguments:
#  exp-len - length of progression (10 by default);
#  rnd_num_1 - first number in progression (2);
#  rnd_min - minimal first number of progression (0 by default)
#  rnd_max - maximal last number of progression (50 by default)
#  exp-end - ending point of progression, all progression (exp-len - 1) by default)
#  the function random sets 1st element and step of progression (within the limits)
#  then it appends other elements by adding the step to each new number

def make_progression(rnd_step, exp_len, rnd_num_1, rnd_min, rnd_max):
    rnd_num_1 = randint(rnd_min, rnd_max)
    exp_progression = [rnd_num_1, ]
    
    for i in range(exp_len):
        rnd_num_next = rnd_num_1 + rnd_step
        exp_progression.append(rnd_num_next)
        rnd_num_1 = rnd_num_next
    
    return exp_progression


def brain_progression():
    name = welcome_user()
    print('What number is missing in the progression?')
    guess_in_row = 0
    
#    rnd_step = randint(1, 5)

#    exp_progression = make_progression(rnd_step, exp_len=10, rnd_num_1=0, rnd_min=0, rnd_max=50)
    while guess_in_row < 3:
        rnd_num_1 = randint(1, 50)
        rnd_step = randint(1, 10)
        exp_len = randint(7, 10)
        rnd_num_last = rnd_num_1 + rnd_step * exp_len

        exp_progression = list(range(rnd_num_1, rnd_num_last, rnd_step))
        rnd_pos = randint(0, exp_len - 1)

        rnd_exp_result = int(exp_progression[rnd_pos])
        exp_progression[rnd_pos] = '..'
        rnd_exp = " ".join(map(str, exp_progression))
        rer = rnd_exp_result

        print(f'Question: {rnd_exp}')
        user_guess = int(prompt.string('Your answer: '))
        ug = user_guess

        if (user_guess == rnd_exp_result):
            print('Correct!')
            guess_in_row += 1
        else:
            print(f'{ug} is wrong answer;(. Correct answer was {rer}.')
            print(f"Let's try again, {name}!")
            return None

    if guess_in_row == 3:
        print(f'Congratulations, {name}!')
        return None
